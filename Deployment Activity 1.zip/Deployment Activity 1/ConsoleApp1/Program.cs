﻿using System;
using System.Windows;

namespace ConsoleApp1
{
    class Program
    {
        static float avgcalc()
        {
            int[] numbers = new int[10] { 4, 5, 8, 1, 3, 6, 7, 9, 5, 3 };
            float sum = 0;
            foreach (int n in numbers)
            {
                sum = sum + n;
            }
            //Console.WriteLine("Total is :{0}\n", sum);
            float avg = sum / numbers.Length;
            return avg;
        }
        static void Main(string[] args)
        {
            float avg = avgcalc();
            if (avg > 10)
                {
                    //Console.WriteLine("Average is :{0}\nDouble digits", avg);
                    MessageBox.Show("Number is a Double digit", "Double OR Single");
            }
                else
                {
                    //Console.WriteLine("Average is :{0}\nSingle digit", avg);
                    MessageBox.Show("Number is a Single digit", "Double OR Single");

            }
        }
    }
}
